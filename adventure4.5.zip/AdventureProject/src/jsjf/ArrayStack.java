package jsjf;

public class ArrayStack<T> implements Stack<T> {
	private final int DEFAULT_CAPACITY = 10;
	private int count;
	private T[] stack; //array of generic type
	
	public ArrayStack(){
		count = 0;
		stack = (T[])(new Object[DEFAULT_CAPACITY]);
	}
	
	public void push(T element){
		if(count == stack.length){
			expandCapacity();
		}
		stack[count] = element;
		count++;
	}
	public T pop() throws EmptyCollectionException{
		if(count == 0){
			throw new EmptyCollectionException("There isn't anything in the stack.");
		}
		T result = stack[count-1];
		count--;
		return result;
	}
	public T peek() throws EmptyCollectionException{ //returns top most element
		if(count == 0){
			throw new EmptyCollectionException("There isn't anything in the stack.");
		}
		T result = stack[count];
		return result;
	}
	public boolean isEmpty(){
		if(count == 0){
			return true;
		}
		else{
			return false;
		}
	}
	public int size(){
		return count;
	}
	private void expandCapacity(){
		T[] larger = (T[])(new Object[stack.length]);
		for(int i = 0; i<stack.length; i++){
			larger[i] = stack[i];
		}
		stack = larger;
	}
	public String toString(){
		String result = "<top of the stack>\n";
		for(int i = count-1; i >= 0; i--){
			result += stack[i] + "\n";
		}
		return result + "<bot of stack>\n";
	}
}
