package jsjf;

public class LinearNode<T> {
	private T element;
	private LinearNode<T> next;
	
	public LinearNode(){ //empty node
		next = null;
		element = null;
	}
	public LinearNode(T elem){
		next = null;
		element = elem;
	}
	public LinearNode<T> getNext(){ //returns reference variable to next linear node
		return next;
	}
	public void setNext(LinearNode<T> node){ //sets reference variable to next linear node
		next = node;
	}
	public T getElement(){
		return element;
	}
	public void setElement(T elem){
		element = elem;
	}
}
