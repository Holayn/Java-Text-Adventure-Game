package Adventure;
/**
 * This class' purpose is to test the vault located in the Library
 * @author Kai Wong
 *
 */
public class TestVault {
	public static void main(String args[]){
		Vault vault = new Vault("", "clue");
		System.out.println("Current vault password: "+vault.getPassword());
		vault.vaultStatus();
		System.out.println("Setting password...");
		vault.setKey();
		System.out.println("Current vault password: "+vault.getPassword());
		System.out.println("Unlocking vault...");
		vault.unlockVault();
		vault.vaultStatus();
		System.out.println("Locking vault again...");
		vault.lockVault();
		vault.vaultStatus();
		System.out.println("If you wish to test the vault's implementation in the game, visit the library and type \"open vault\". Password is poop.");
		
	}
}
