/**
 * This class was created in order to make the main method shorter and more manageable
 * 
 * @author Kai Wong, Christian DeLeaon, Kostikey Mustakas
 */
package Adventure;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Location {
	//----------------------------------------------------------------------------------------
	//CREATING ROOMS AND ITEMS
	/**
	 * Keeping track of player location
	 * @author Kai
	 */
	public static int currentRoomx = 1;
	public static int currentRoomy = 2;
	private static Random rand = new Random(); //creating random object
	private static int randx, randy; //coordinates for random room
	private static int locWidth, locHeight, numofcoins; //storing constants WIDTH and HEIGHT. numofcoins is for number of coins for each Coin item.
	private static LinkedStack<String> roomstack = new LinkedStack<String>(); //history of rooms visited stored in a stack. stores room as its string name.
	private static LinkedQueue<String> roomqueue = new LinkedQueue<String>(); //history of rooms visited stored in a queue. stores room as its string name.
	private static int score = 0; //player's score
	/**
	 * Creating rooms in the array passed down from main. Created in a 2D array. This method creates WIDTH X HEIGHT rooms in total.
	 * However, there may not necessarily be WIDTH X HEIGHT rooms in total. Therefore, we need to set rooms as true or false, in order 
	 * to prevent the player from walking into an undefined room.
	 * @param rooms (the room array passed down from main)
	 * @param WIDTH (the width of the room array)
	 * @param HEIGHT (the height of the room array)
	 * @throws IOException (program throws this exception if magicitems.txt cannot be found)
	 * @author Kai
	 */
	public static void makeRooms(Room[][] rooms, int WIDTH, int HEIGHT) throws IOException{ //Christian implemented this
		locWidth = WIDTH; //setting constants to local variable in Location class
		locHeight = HEIGHT;
		for (int j = 0; j<HEIGHT; j++){
			for (int i = 0; i<WIDTH; i++){
				//have to set rooms true with changeRoomExist() if the room is a room the player can navigate to.
				//have to set titles and descriptions with mutator methods as well
				rooms[i][j] = new Room("", "", false);
			}
		}
		/**
		 * Instantiating Magic Shop in room array. Magic Shop is a special type of Room.
		 */
		rooms[0][0] = new Shop("Magic Shop", "A small, dusty magic shop. No one has been in here for ages. The exit lies to the east.", false);
		rooms[1][2] = new Lab("", "", false);
		rooms[2][1] = new Library("", "", false);
		/**
		 * Defining all room titles and descriptions using mutators setTitle and setDescription.
		 */
		rooms[1][0].setTitle("Market");
		rooms[2][0].setTitle("Food Store");
		rooms[1][1].setTitle("Hallway");
		rooms[1][2].setTitle("Lab");
		rooms[2][1].setTitle("Library");
		rooms[2][2].setTitle("Bedroom");
		rooms[3][2].setTitle("Bathroom");
		rooms[1][0].setDescription("You are outside in a deserted market square. The sun shines down brightly on the flagstones beneath your feet, and the breeze ruffles your clothes. An abandoned magic shop is to the west, and a food store is to the east. The door to your house is to the south.");
		rooms[2][0].setDescription("You are in a tiny, empty corner food store. The only thing in here is a fruit crate. The door to the exit is to the west.");
		rooms[1][1].setDescription("You find yourself in a long, empty hallway leading between the lab and the outside market. The door outside is to the north, and the lab is to the south.");
		rooms[1][2].setDescription("You are in a fancy laboratory. The room is filled with state-of-the-art equipment. To the east, you see the doorway to your bedroom. There is a hallway to the north.\nA combiner sits in the corner.");
		rooms[2][1].setDescription("You are in a large, well-kept library, with bookshelves towering up to the ceiling. The exit is to the south.\nA metal vault sits in the corner of the room. A picture of a toilet is stuck to its side.");
		rooms[2][2].setDescription("You are in a tiny bedroom, containing only a hard-looking bed and a nightstand. There is a bathroom to the east. The door west leads back to the lab. A library is to the north.");
		rooms[3][2].setDescription("You are in a smelly bathroom. There is only a toilet and a sink in here. The bedroom is to the west.");
		/**
		 * Pushing/enqueueing first location the player starts in to the history stack and queue.
		 */
		roomstack.push(rooms[currentRoomx][currentRoomy].getTitle());
		roomqueue.enqueue(rooms[currentRoomx][currentRoomy].getTitle());
		rooms[currentRoomx][currentRoomy].visitedRoom(); //player does not get their score increased for going back to the room they started in
	}
	/**
	 * Calls the run method that every room has. This allows the room to perform a special action, such as open a shop.
	 * Generic rooms as of now do not have a run method defined.
	 * @param rooms (the 2D room array)
	 * @param inventory (the arraylist containing items the player is holding)
	 * @author Kai
	 */
	public static void check(Room[][] rooms, ArrayList<Item> inventory){
		rooms[currentRoomx][currentRoomy].run(inventory); 
	}
	/**
	 * Adds items into specific room's item arraylists. Name, description, takeable, cost, weight
	 * @param rooms (the 2D room array)
	 * @author Kai
	 */
	public static void makeItems(Room[][] rooms){
		/**
		 * Takeable items
		 */
		rooms[2][2].addItem(new Item("shopping list", "It reads: \"On sale now at the Magic Shop! Small shield, white sword, endless rope, helm, rags, and more! Come quick before it's all gone!\"", true, "cheap", 1));
		rooms[1][2].addItem(new Map("map", "A small, wrinkled map", true, "cheap", 1));
		rooms[3][2].addItem(new Item("bottle", "A small, glass bottle", true, "cheap", 2));
		rooms[2][1].addItem(new Item("book", "A thick and heavy tome.\nYou flip through its dusty pages and find an entry under \"Cures.\"\n-----\nDiarrhea cure: Combine rags, a small shield, and an apple with a bottle, and drink.", true, "cheap", 3));
		rooms[2][0].addItem(new Item("apple", "A tasty red apple", true, "cheap", 2));
		rooms[2][0].addItem(new Item("banana", "A long, yellow banana", true, "cheap", 2));
		rooms[2][0].addItem(new Item("chips", "Cheesy chaaaaaps!", true, "cheap", 2));
		/**
		 * Non-takeable items
		 */
		rooms[1][2].addItem(new Item("combiner", "A machine used to combine ingredients to make a potion. It needs a bottle, along with proper ingredients.\nA small label on the side reads: \"Model 2.0 now senses when you have the right ingredients to make a potion! Don't forget your bottle!\"", false, "", 0));
		//adding vault to room
		rooms[2][1].addItem(new Item("vault", "A small, sturdy vault", false, "", 0));
		rooms[2][1].addItem(new Item("picture", "A picture of a toilet. You think it's a clue of some kind.", false, "", 0));
		rooms[3][2].addItem(new Item("toilet", "An ordinary white toilet. You peer inside the bowl and see the words \"poop\" scratched into the ceramic. Is it some kind of password? Who knows!", false, "", 0));
		rooms[3][2].addItem(new Item("sink", "A shallow sink. Nothing too special.", false, "", 0));
		rooms[2][2].addItem(new Item("bed", "This bed doesn't look very comfortable to sleep on.", false, "", 0));
		rooms[2][2].addItem(new Item("nightstand", "A short, wooden nightstand.", false, "", 0));
		rooms[1][2].addItem(new Item("equipment", "Fancy, shiny equipment. Ooooh, I must touch them all.", false, "", 0));
		rooms[2][0].addItem(new Item("fruit crate", "A crate designed to hold a lot of fruit.", false, "", 0));
		rooms[2][0].addItem(new Item("crate", "A crate designed to hold a lot of fruit.", false, "", 0));
		rooms[2][1].addItem(new Item("bookshelves", "The bookshelves have so many books you could spend a lifetime reading them all.", false, "", 0));
		rooms[1][0].addItem(new Item("sun", "Don't stare too long at the sun!", false, "", 0));
		rooms[1][0].addItem(new Item("flagstones", "Flat stones that make up the ground beneath you.", false, "", 0));
		/**
		 * Making coins appear in random rooms with random amounts. Player can hold as many coins as they want.
		 */
		randomGen();//generating random room number and coin number
		rooms[randx][randy].addItem(new Coin("coins", "A small pile of gold coins", true, "", 0, numofcoins));
		randomGen();//generating random room number and coin number
		rooms[randx][randy].addItem(new Coin("coins", "A small pile of gold coins", true, "", 0, numofcoins));
		randomGen();
		rooms[1][0].addItem(new Coin("coins", "A small pile of gold coins", true, "", 0, numofcoins));
	}
	/**
	 * Generating random room numbers and random coin amounts. Private because helper method.
	 */
	private static void randomGen(){ 
		randx = rand.nextInt(locWidth); //integer will be random number between 0 and x-1 dimension of array
		randy = rand.nextInt(locHeight); //integer will be random number between 0 and y-1 dimension of array
		numofcoins = rand.nextInt(40) + 20; //generating random number of coins between 20 and 40.
	}
	/**
	 * When executed, method examines inputed item in the room or in the player's inventory
	 * @param string (the item input from the user)
	 * @param inventory (the items the user is holding)
	 * @param rooms (the 2D room array)
	 * @author Kai
	 */
	public static void examineItem(String string, ArrayList<Item> inventory, Room[][] rooms){
		boolean itemExists = false; //boolean is set to true if item is in room item arraylist or player inventory
		while(itemExists == false){
			for(int i = 0; i<rooms[currentRoomx][currentRoomy].getRoomItems().size(); i++){ //iterating through room's item arraylist
				if(rooms[currentRoomx][currentRoomy].getRoomItems().get(i).getItemName().equals(string)){
					System.out.println(rooms[currentRoomx][currentRoomy].getRoomItems().get(i).getDescription()); //returns description of item and prints it
					itemExists = true; //sets itemExists to true because item found in inventory
				}
			}
			for(int i = 0; i<inventory.size(); i++){ //iterating through player inventory
				if (inventory.get(i).getItemName().equals(string)){
					System.out.println(inventory.get(i).getDescription()); //returns description of item and prints it
					itemExists = true; //sets itemExists to true because item found in inventory
				}
			}
			if(itemExists != true){
				/**
				 * Coins has its own special conditional, because coins aren't set as an item in the player's inventory. Instead, its amount
				 * is added to a variable that keeps track of how much gold the player has picked up.
				 */
				if(string.equals("coins")){
					int numofcoins = Inventory.numofCoins();
					if(numofcoins == 0){ //if player is not holding any coins
						System.out.println("That item does not exist.");
						itemExists = true; //in order to prevent second !itemExists conditional from executing
					}
					else{ //if player is holding coins
						System.out.println("A small pile of gold coins.");
						itemExists = true;
					}
				}
			}
			if(!itemExists){ //if boolean was never set to true (if item wasn't in inventory or room), then print "item does not exist"
				System.out.println("That item does not exist.");
				itemExists = true;
			}
		}
	}
	
	//----------------------------------------------------------------------------------------
	/**
	 * @return int This returns the x coord of the current position in 2D array
	 */
	public static int getCurrentRoomx(){
		return currentRoomx;
	}
	/**
	 * @return int This returns the y coord of the current position in 2D array
	 */
	public static int getCurrentRoomy(){
		return currentRoomy;
	}
	/**
	 * @param x Sets current x coord to x
	 */
	public static void setCurrentRoomx(int x){
		currentRoomx = x;
	}
	/**
	 * @param y Sets current y coord to y
	 */
	public static void setCurrentRoomy(int y){
		currentRoomy = y;
	}
	/**
	 * Prints the room's description
	 * @param rooms (the 2D room array)
	 */
	public static void returnDescription(Room[][] rooms){
		System.out.println(rooms[currentRoomx][currentRoomy].getDescription()); //returns description of current room
	}
	/**
	 * Prints the room's title, description, and the items it contains
	 * @param rooms (the 2D room array)
	 * @author Christian
	 */
	public static void printRoom(Room[][] rooms){
		System.out.println(rooms[currentRoomx][currentRoomy]);
	}
	/**
	 * Adds item input by player to player inventory by calling takeItem method in Room class
	 * @param string (item name input by player)
	 * @param inventory (items held by player)
	 * @param rooms (2D room array)
	 * @author Kai
	 */
	public static void takeItem(String string, ArrayList<Item> inventory, Room[][] rooms){ 
		rooms[currentRoomx][currentRoomy].takeItem(string, inventory); 
	}
	/**
	 * Removes item input by player from player inventory by calling dropItem method in Room class
	 * @param string (item name input by player)
	 * @param inventory (items held by player)
	 * @param rooms (2D room array)
	 * @author Kai
	 */
	public static void dropItem(String string, ArrayList<Item> inventory, Room[][] rooms){
		rooms[currentRoomx][currentRoomy].dropItem(string, inventory); 
	}
	/**
	 * Method to move player from room to room. Prints out room name and description whenever the player enters a new room.
	 * THIS METHOD ALSO KEEPS TRACK OF LOCATIONS VISITED BY STORING LOCATION INSIDE OF A LINKED QUEUE OR LINKED STACK.
	 * @param direction (direction input by the player)
	 * @param rooms (2D room array)
	 * @param WIDTH (width of the room array)
	 * @param HEIGHT (height of the room array)
	 * @author Kai
	 */
	public static void Navigation(String direction, Room[][] rooms, int WIDTH, int HEIGHT){ 
		setRooms(rooms); //see method comment for details on what this method does. changing room existences.
		/**
		 * Storing current room in history array
		 */
		try{
			if (direction.equals("n")){
				if (currentRoomy>0){
					if (rooms[currentRoomx][currentRoomy-1].doesRoomExist()){ //so player does not go into undefined room in array
						currentRoomy -= 1;
						printRoom(rooms);
						roomstack.push(rooms[currentRoomx][currentRoomy].getTitle()); //pushes new room's title to stack
						roomqueue.enqueue(rooms[currentRoomx][currentRoomy].getTitle()); //enqueues new room's title to queue
					}
					else{
						System.out.println("You can't go that way!");
					}
				}
				else{
					System.out.println("You can't go that way!");
				}
			}	
			if (direction.equals("s")){
				if (currentRoomy<HEIGHT){
					if (rooms[currentRoomx][currentRoomy+1].doesRoomExist()){
						currentRoomy += 1;
						printRoom(rooms);
						roomstack.push(rooms[currentRoomx][currentRoomy].getTitle()); //pushes new room's title to stack
						roomqueue.enqueue(rooms[currentRoomx][currentRoomy].getTitle()); //enqueues new room's title to queue
					}
					else{
						System.out.println("You can't go that way!");
					}
				}
				else{					
					System.out.println("You can't go that way!");
				}
			}
			if (direction.equals("e")){
				if (currentRoomx<WIDTH){
					if (rooms[currentRoomx+1][currentRoomy].doesRoomExist()){
						currentRoomx += 1;
						printRoom(rooms);
						roomstack.push(rooms[currentRoomx][currentRoomy].getTitle()); //pushes new room's title to stack
						roomqueue.enqueue(rooms[currentRoomx][currentRoomy].getTitle()); //enqueues new room's title to queue
					}
					else{
						System.out.println("You can't go that way!");
					}
				}
				else{					
					System.out.println("You can't go that way!");
				}
			
			}
			if (direction.equals("w")){
				if (currentRoomx>0){
					if (rooms[currentRoomx-1][currentRoomy].doesRoomExist()){
						currentRoomx -= 1;
						printRoom(rooms);
						roomstack.push(rooms[currentRoomx][currentRoomy].getTitle()); //pushes new room's title to stack
						roomqueue.enqueue(rooms[currentRoomx][currentRoomy].getTitle()); //enqueues new room's title to queue
					}
					else{
						System.out.println("You can't go that way!");
					}
				}
				else{					
					System.out.println("You can't go that way!");
				}
			}
			/**
			 * Increments player's score every time player visits a new room
			 */
			if(rooms[currentRoomx][currentRoomy].hasVisited()==false){
				rooms[currentRoomx][currentRoomy].visitedRoom();
				score++;
				System.out.println("Your score has gone up by one!");
			}
		}
		/**
		 * This try/catch statement is for if the currentRoomx or currentRoomy references to index outside of the 2D array
		 * For example, when in lab, and and player tries to go south. The navigation method tries to add 1 to currentRoomy. Out of bounds.
		 */
		catch (ArrayIndexOutOfBoundsException exception){
			System.out.println("You can't go that way, silly!");
		}
	}
	/**
	 * Prevents navigation between rooms without a doorway between them. This happens because rooms are in an array.
	 * This method now causes rooms to exist only in relation to the player. The player may only enter rooms that exist.
	 * At the end of every iteration of main, all the rooms are set to false again.
	 * When calling the navigation method again, sets rooms the player can go to as true.
	 * @param rooms (the 2D room array)
	 * @author Kai
	 */
	private static void setRooms(Room[][] rooms){
		switch(rooms[currentRoomx][currentRoomy].getTitle()){
		case "Magic Shop":
			rooms[1][0].changeRoomExist(); //setting Market room to true. this means the player can go to the market. other rooms are false, so player can't go to those rooms.
			break;
		case "Market":
			rooms[0][0].changeRoomExist();
			rooms[2][0].changeRoomExist();
			rooms[1][1].changeRoomExist();
			break;
		case "Food Store":
			rooms[1][0].changeRoomExist();
			break;
		case "Hallway":
			rooms[1][0].changeRoomExist();
			rooms[1][2].changeRoomExist();
			break;
		case "Lab":
			rooms[1][1].changeRoomExist();
			rooms[2][2].changeRoomExist();
			break;
		case "Bedroom":
			rooms[1][2].changeRoomExist();
			rooms[2][1].changeRoomExist();
			rooms[3][2].changeRoomExist();
			break;
		case "Library":
			rooms[2][2].changeRoomExist();
			break;
		case "Bathroom":
			rooms[2][2].changeRoomExist();
			break;
		}
	}
	/**
	 * Sets all rooms to false existence
	 * @param rooms (2D room array)
	 * @param WIDTH (width of room array)
	 * @param HEIGHT (height of room array)
	 * @author Kai
	 */
	public static void removeRooms(Room[][] rooms, int WIDTH, int HEIGHT){
		for (int j = 0; j<HEIGHT; j++){
			for (int i = 0; i<WIDTH; i++){
				rooms[i][j].changeRoomExist(false);
			}
		}
	}
	public static void openThing(String str, ArrayList<Item> inven, Room[][] rooms){
		if(rooms[currentRoomx][currentRoomy].getTitle().equals("Library")){
			if(str.equals("vault")){
				rooms[currentRoomx][currentRoomy].run(inven, rooms[currentRoomx][currentRoomy].getItems());
			}
		}
	}
	/**
	 * Gets the player's score
	 * @return score (player's score)
	 */
	public static int getScore(){
		return score;
	}
	/**
	 * Ask if player wants to review actions forwards or backwards. Returns queue or stack depending on answer
	 * @author Kai
	 */
	public static void reviewActions(){
		System.out.println("Do you want to review your walk-through of the game?");
		boolean asking = true;
		while(asking){
			String ans = Input.getInput();
			if(ans.equals("yes")||ans.equals("y")){
				System.out.println("Do you want to review your locations visited forwards or backwards?");
				while(asking){
					ans = Input.getInput();
					if(ans.equals("forwards")||ans.equals("forward")){
						asking = false;
						System.out.println("Here are your locations visited in forward order:");
						while(!roomqueue.isEmpty()){
							System.out.println(roomqueue.dequeue());
						}
					}
					else if (ans.equals("backward")||ans.equals("backwards")){
						asking = false;
						System.out.println("Here are your locations visited in reverse order:");
						while(!roomstack.isEmpty()){
							System.out.println(roomstack.pop());
						}
					}
					else{
						System.out.println("Please enter a valid string.");
					}
				}
			}
			else if(ans.equals("no")||ans.equals("n")){
				System.out.println("Okay, have a nice day!");
				asking = false;
			}
			else{
				System.out.println("Please enter a valid string.");
			}
		}
	}
}
