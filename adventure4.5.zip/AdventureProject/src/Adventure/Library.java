package Adventure;

import java.util.ArrayList;

/**
 * Special room. Contains the vault.
 * @author Kai Wong
 *
 */
public class Library extends Room {
	private Vault vault;
	public Library(String title, String description, boolean bool){
		super(title, description, bool);
		vault = new Vault("poop", "Go check the bathroom");
	}
	/**
	 * Run method for library. Notice that this run method is an overloaded run method.
	 * Checks to see if vault is locked. If it is, then prompts player to add password. Player can ask for clue. If password is correct,
	 * vault unlocks and treasure is added to the room.
	 */
	public void run(ArrayList<Item> inven, ArrayList<Item> items){
		if(vault.vaultLocked()){
			System.out.println("The vault is locked. A small keypad is located on the door. Do you wish to try a password?");
			boolean ask = true;
			while(ask){
				String str = Input.getInput();
				if(str.equals("yes")||str.equals("y")){
					ask = false;
					System.out.println("Enter password: ");
					str = Input.getInput();
					if(str.equals(vault.getPassword())){
						vault.unlockVault();
						System.out.println("The vault clicks open, and treasure spills into the room!");
						items.add(new Item("treasure", "A large pile of treasure", true, "super expensive", 5));
						//add treasure to room
					}
					else{
						System.out.println("The vault emits a loud beeping noise.\nDo you want a clue?");
						str = Input.getInput();
						boolean ask2 = true;
						while(ask2){
							if(str.equals("yes")||str.equals("y")){
								System.out.println(vault.getClue());
								System.out.println("You step away from the vault.");
								ask2 = false;
							}
							else if(str.equals("no")||str.equals("n")){
								System.out.println("You step away from the vault.");
								ask2 = false;
							}
							else{
								System.out.println("That's not a valid statement.");
							}
						}
					}
				}
				else if(str.equals("no")||str.equals("n")){
					ask = false;
					System.out.println("You step away from the vault.");
				}
				else{
					System.out.println("That's not a valid response.");
				}
			}
		}
		else{
			System.out.println("You've already opened the vault!");
		}
	}
}
