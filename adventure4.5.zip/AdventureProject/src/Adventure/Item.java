package Adventure;

/**
 * Implements items the player can pick up and place in their inventory.
 * @author Kai
 *
 */

public class Item {
	protected String m_name; //name of item
	protected String m_description; //description of item
	protected boolean takeable; //item can be takeable or nontakeable
	protected int weight; //weight of an item
	protected String cost;
	
	/**
	 * Constructor for Items
	 * @param name (name of item)
	 * @param description (description of item)
	 * @param bool (if set to true, the item is takeable by the player. if set to false, the item is not takeable by the player)
	 */
	public Item(String name, String description, boolean bool, String cost, int weight){
		m_name = name;
		m_description = description;
		takeable = bool;
		this.cost = cost;
		this.weight = weight;
	}
	/**
	 * Mutator for item's name
	 * @param string (item name)
	 */
	public void setName(String string){
		m_name = string;
	}
	/**
	 * Accessor for item's name
	 * @return string (item's name)
	 */
	public String getItemName(){
		return m_name;
	}
	/**
	 * Mutator for item's description
	 * @param string (item's description)
	 */
	public void setDescription(String string){
		m_description = string;
	}
	/**
	 * Overridden by Map class, which inherits from item.
	 * TODO: Fix this
	 * @param roomx (x coordinate of location)
	 * @param roomy (y coordinate of location)
	 */
	public void showMap(int roomx, int roomy){ 
	}
	/**
	 * @return int (Returns the quantity of the item)
	 */
	/**
	 * Overridden by Coin class, which inherits from item.
	 * TODO: Fix this
	 * @return
	 */
	public int getQuantity(){
		return 1;
	}
	/**
	 * Accessor for room's description
	 * @return string (description of room)
	 */
	public String getDescription(){
		return m_description;
	}
	/**
	 * Returns the item's weight
	 * @return int (item's weight)
	 */
	public int returnWeight(){
		return weight;
	}
	/**
	 * Returns the boolean if item is takeable or not.
	 * @return boolean 
	 */
	public boolean isTakeable(){
		return takeable;
	}
	/**
	 * Overriding toString method
	 * @return string (name of item)
	 */
	public String toString(){
		return m_name;
	}
}
