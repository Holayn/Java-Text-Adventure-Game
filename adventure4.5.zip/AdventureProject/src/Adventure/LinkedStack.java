package Adventure;
import jsjf.Stack;
import jsjf.LinearNode;
import jsjf.EmptyCollectionException;

/**
 * Linked stack consists of a linked list of linear nodes. linear nodes consist of a T element and a reference to another linear node
 * @author Kai Wong
 * @param <T>
 */


public class LinkedStack<T> implements Stack<T>{
	
	private int count;
	private LinearNode<T> top; //reference to top of the stack
	
	public LinkedStack(){
		count = 0;
		top = null;
	}
	public void push(T element){
		LinearNode<T> current = top; //storing reference to top of stack in variable current
		top = new LinearNode<T>(element); //setting top of stack to a new linear node
		top.setNext(current); //sets the reference of top to the top of the stack. now top is the top of the stack, and current is underneath it
		count++;
	}
	public T pop() throws EmptyCollectionException{
		if (count == 0){
			throw new EmptyCollectionException("Stack is empty");
		}
		T result = top.getElement();
		top = top.getNext();
		count--;
		return result;
	}
	public T peek() throws EmptyCollectionException{
		if (count == 0){
			throw new EmptyCollectionException("Stack is empty");
		}
		T result = top.getElement();
		return result;
	}
	public boolean isEmpty(){
		if (count == 0){
			return true;
		}
		else{
			return false;
		}
	}
	public int size(){
		return count;
	}
	public String toString(){
		String result = "<top of stack>\n";
		LinearNode<T> current = top;
		while(current != null){
			result += current.getElement() + "\n";
			current = current.getNext();
		}
		return result + "<bot of stack>\n";
	}
}
