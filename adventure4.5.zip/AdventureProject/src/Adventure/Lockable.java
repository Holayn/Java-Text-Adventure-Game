package Adventure;

public interface Lockable {
	public void lockVault();
	public void unlockVault();
	public void setKey();
	public void vaultStatus();
}
