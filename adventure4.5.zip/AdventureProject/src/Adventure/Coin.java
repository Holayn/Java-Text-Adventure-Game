package Adventure;

/**
 * Coin is a special type of Item
 * @author Kai
 *
 */

public class Coin extends Item{
	/**
	 * The amount of coins the Coin object has. Each Coin object has a different number of coins.
	 */
	private int numofcoins; 
	/**
	 * Constructor
	 * @param name (name of coins)
	 * @param description (description of coins)
	 * @param bool (this boolean is set to true. allows player to pick up coins)
	 * @param num (number of coins in Coin object)
	 */
	public Coin(String name, String description, boolean bool, String cost, int weight, int num){
		super(name, description, bool, cost, weight);
		numofcoins = num;
	}
	/**
	 * Accessor for number of coins in Coin object
	 * @return int (number of coins in Coin object)
	 */
	public int getQuantity(){
		return numofcoins;
	}
	/**
	 * Accessor for description of Coin object
	 * @return string (Coin object description with number of coins it has)
	 */
	public String getDescription(){
		return "A small pile of "+numofcoins+" coins.";
	}
	/**
	 * Overriding toString method
	 * @return string (returns "coins")
	 */
	public String toString(){
		return "coins";
	}
}
