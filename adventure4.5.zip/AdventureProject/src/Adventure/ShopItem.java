package Adventure;

/**
 * Items that exist in the shop. These are read in from magicitems.txt.
 * @author Kai
 *
 */

public class ShopItem extends Item implements Comparable{
	private int price;
	/**
	 * Constructor
	 * @param name (name of shop item)
	 * @param description (description of shop item)
	 * @param bool (boolean to see if shop item is takeable or not)
	 * @param price (price of each shop item)
	 */
	public ShopItem(String name, String description, boolean bool, String cost, int weight, int price){
		super(name, description, bool, cost, weight);
		this.price = price;
	}
	/**
	 * Accessor for shop item's price
	 * @return int (shop item's price)
	 */
	public int getPrice(){
		return price;
	}
	/**
	 * Compares the object's item name
	 */
	public int compareTo(Object obj){
		int result = this.getItemName().compareTo(((Item)obj).getItemName());
		return result;
	}
}
