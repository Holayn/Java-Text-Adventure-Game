package Adventure;

import java.util.*;
import java.io.*;

/**
 * Special room that inherits properties from the Room class.
 * @author Kai
 *
 */

public class Shop extends Room{
	LinkedList<ShopItem> tempshoplist = new LinkedList<ShopItem>(); //linked list for shop items. used for reading in items from magicitems.txt
	ShopItem[] shoplist; //fixed-length array for shop items, copied from linkedlist into array
	LinkedQueue<String> purchaseditems = new LinkedQueue<String>(); //keeping track of items purchased by player from the magic shop
	File file = new File("magicitems.txt");
	Random rand = new Random(); //this is to set random gold prices
	boolean stillScanning = true; //to see if list has items left to store in game
	String string;
	boolean hasItem = false; //to see if what player entered exists in shop
	boolean ask = true; //to see if player still wants to ask for item from shop
	boolean stillShopping = true; //to see if player is still shopping
	int current = 0; //integer variable for adding shop items from linked list to array
	/**
	 * Constructor
	 * Executes room's make method. Reads in items from magicitems.txt
	 * @param title (name of room)
	 * @param description (description of room)
	 * @param bool (existence of room)
	 * @throws IOException (if magicitems.txt cannot be found)
	 */
	public Shop(String title, String description, boolean bool) throws IOException{
		super(title, description, bool);
		try{
			make();
		}
		catch(IOException ex){
			System.out.print(ex + " Please place the magicitems.txt file in the project folder.");
		}
	}
	/**
	 * Method to read in items from magicitems file. Creates new shop item for each item read in from the file and stores it in 
	 * the shoplist linkedlist. All shop items are inexpensive and are given a weight value of 5.
	 * @throws IOException (if there is error with magicitems.txt)
	 */
	public void make() throws IOException{ 
		Scanner scan = new Scanner(file);
		while(scan.hasNextLine()){
			string = scan.nextLine();
			string = string.toLowerCase();
			int price = rand.nextInt(20)+1;
			tempshoplist.add(new ShopItem(string, string, true, "inexpensive", 5, price));
		}
		/**
		 * Making a new fixed-length array. Iterates through linked list item by item, copies item into array
		 * Increases index by one. Continues to loop until iterator reaches end of the linked list.
		 * Sorts the list alphabetically.
		 */
		shoplist = new ShopItem[tempshoplist.size()];
		ListIterator<ShopItem> itr = tempshoplist.listIterator();
		while(itr.hasNext()){
			shoplist[current] = itr.next();
			current++;
		}
		sort(shoplist);
		scan.close();
	}
	/**
	 * Room's run method. Executes when the player enters the Shop, allows the player to purchase items from the shop.
	 * When player requests an item, method searches for request by linear searching through the linked list of shop items.
	 * If item is found, displays cost of item and asks player if they want to buy it. If player has enough gold pieces,
	 * item is added to player inventory. Then asks if player wants to continue shopping. Makes sure player can hold item's weight before letting
	 * player buy item.
	 * @author Kai
	 */
	public void run(ArrayList<Item> inventory){
		hasItem = false; //to see if what player entered exists in shop
		ask = true; //to see if player still wants to ask for item from shop
		stillShopping = true;
		String askitem = ""; //user's input
		System.out.println("\nYou enter the dusty, old magic shop and approach the counter.\n\"What would you like to buy?\" a voice asks from behind a dusty curtain.");
		while(stillShopping){
			try{
				askitem = Input.getInput();
				ShopItem temp = new ShopItem(askitem, "", true, "", 0, 0); //creating a temporary shopitem to compare to in the shoplist array
				hasItem = false;
				//add binary search
				//ListIterator<ShopItem> itr = tempshoplist.listIterator(); //linear searching through linked list
				ShopItem item = (ShopItem)Search.binarySearch(shoplist, temp);
				//ShopItem item = itr.next();
				if(askitem.equals(item.getItemName())){ //comparing string request with item's string name
					System.out.println("Yes, we have a "+askitem+". That will cost you "+item.getPrice()+"."); //prints item name and price
					System.out.println("Do you want to buy this item?"); //asking if player wants item
					hasItem = true; //shop had item
					ask = true;
					while(ask){
						String request = Input.getInput();
						if(request.equals("yes")||request.equals("y")){
							if(Inventory.getCarryAmount()+item.returnWeight()<=Inventory.getCarryWeight()){
								if(Inventory.numofCoins() > item.getPrice()){
									System.out.println("A "+item.getItemName()+" has been added to your inventory. "+item.getPrice()+" coins removed from inventory.");
									System.out.println("\"Thanks for shopping!\" The voice then fades away and you are left alone again.");
									Inventory.removeCoins(item.getPrice());
									Inventory.addCarryAmount(item.returnWeight());
									addShopItem(item, inventory); //adds item to inventory
									purchaseditems.enqueue(item.getItemName()); //enqueues purchased item's name to purchaseditems queue
									stillShopping = false; //shopkeeper can stop asking player now
									ask = false; //added this
								}
								else{
									System.out.println("You don't have enough coins to purchase that item.");
									anotherItem(inventory); //prompt player if they want to continue shopping
								}
							}
							else{
								System.out.println("You don't have enough strength to carry so many things! Get rid of some things in your inventory, then come back!");
								System.out.println("The voice then fades away and you are left alone again.");
								ask = false;
								stillShopping = false;
								hasItem = true;
							}
						}
						else if (request.equals("no")||request.equals("n")){
							System.out.println("Very well.");
							anotherItem(inventory); //prompt player if they want to search for another item
						}
						else{
							System.out.println("That is not a valid response. Valid responses: yes/no.");
						}
					}
				}
//				else if(askitem.equals("nothing")){
//					System.out.println("Very well then. See you later! The voice then fades away and you are left alone.");
//					hasItem = true;
//				}
			}
			/**
			 * If the user types in an invalid item, the program throws a NullPointerException. Handling it by asking player
			 * to input a new item.
			 */
			catch(NullPointerException excep){
				System.out.println("Sorry, we do not have a "+askitem+".");
				ask = false;
				anotherItem(inventory);
			}
		}
		if(hasItem == false){
			System.out.println("Sorry, we do not have a "+askitem+".");
			anotherItem(inventory); //prompt player if they want to search for another item
		}
	}
	/**
	 * Helper method for Shop's run method. Asks the player if they want to continue shopping or not.
	 * @param inventory (player's inventory)
	 */
	private void anotherItem(ArrayList<Item> inventory){
		boolean stayask = true; //asking if player wants to stay in shop
		System.out.println("Search for another item?");
		while(stayask){
			//System.out.println("anotherItem getInput");
			String answer = Input.getInput();
			if(answer.equals("y")||answer.equals("yes")){			
				stayask = false; //shopkeeper can stop asking player now
				ask = false;
				System.out.println("What would you like to buy?");
//				this.run(inventory); //run the shop again
			}
			else if(answer.equals("n")||answer.equals("no")){
				System.out.println("\"Come back another time!\" the voice says. The voice then fades away and you are left alone.");
				//hasItem = true; //in order to prevent infinite loop
				stayask = false; //shopkeeper can stop prompting player now
				ask = false;
				stillShopping = false;
				hasItem = true;
			}
			else{
				System.out.println("That is not a valid response. Valid responses: yes/no.");
				//not setting ask to false because shopkeeper needs to continue prompting player
			}
		}
	}
	/**
	 * Helper method to add items from the shoplist into the player's inventory
	 * @param shopitem (shop item from the list)
	 * @param inventory (player's inventory)
	 */
	private void addShopItem(ShopItem shopitem, ArrayList<Item> inventory){
		inventory.add(shopitem); //adds item to inventory.
		
	}
	/**
	 * Alphabetical sort method. Bubble sort. Goes through array. Compares first array item's name against rest of array item names. If a name of an item
	 * belongs in front of the first array item name, then the items switch place in the array.
	 * @param shoplist The array of the shop items
	 * @author Kai
	 */
	private void sort(ShopItem[] shoplist){
		for(int j = 0; j<shoplist.length; j++){
			for(int i = j+1; i<shoplist.length; i++){
				if((shoplist[i].getItemName()).compareTo(shoplist[j].getItemName()) < 0){
					ShopItem temp = shoplist[j];
					shoplist[j] = shoplist[i];
					shoplist[i] = temp;
				}
			}
		}
	}
	/**
	 * Prints out the items purchased by the player in order from first to last
	 */
	public String returnItems(){
		String str = "";
		while(!purchaseditems.isEmpty()){
			str += purchaseditems.dequeue() + ". ";
		}
		return str;
	}
	
}
