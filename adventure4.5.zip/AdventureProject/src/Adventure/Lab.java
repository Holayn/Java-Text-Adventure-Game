package Adventure;

import java.util.ArrayList;
import java.util.ListIterator;

/**
 * Special room. Contains potion combiner.
 * @author Kai Wong
 *
 */

public class Lab extends Room{
	private boolean potionMade = false;;
	public Lab(String title, String description, boolean visited){
		super(title, description, visited);
	}
	/**
	 * Lab's run method. WIN CONDITION. Allows for creation of potion to win the game. Player needs to have an apple, rags, a small shield, and a bottle in their inventory
	 * for this method to execute.
	 */
	public void run(ArrayList<Item> inventory){
		boolean apple = false, shield = false, rags = false, bottle = false;
		for(int i=0;i<inventory.size();i++){
			if(inventory.get(i).getItemName().equals("apple")){
				apple = true;
			}
			else if(inventory.get(i).getItemName().equals("small shield")){
				shield = true;
			}
			else if(inventory.get(i).getItemName().equals("rags")){
				rags = true;
			}
			else if(inventory.get(i).getItemName().equals("bottle")){
				bottle = true;
			}
		}
		if(apple&&shield&&rags&bottle){
			System.out.println("The potion combiner in the corner suddenly emits a loud beeping noise and springs to life! It seems like you have the right ingredients to make a cure for your diarrhea.");
			System.out.println("Do you wish to combine an apple, a small shield, some rags, and a bottle to make a potion?");
			String ans = Input.getInput();
			if(ans.equals("yes")){
				System.out.println("You use the combiner to create a cure for diarrhea! You down it in one go and you feel much better!");
				System.out.println("----------------------------------------CONGRATULATIONS!-----------------------------------------------------");
				System.out.println("You've won the game! You may continue exploring, or you may quit. Thanks for playing!");
				System.out.println("-------------------------------------------------------------------------------------------------------------");
				/**
				 * Removing items from inventory after they are used in potion...
				 */
				ListIterator<Item> itr = inventory.listIterator();
				while(itr.hasNext()){
					Item item = itr.next();
					if(item.getItemName().equals("apple")){
						Inventory.removeCarryAmount(item.returnWeight());
						itr.remove(); //avoiding concurrentmodificationexception
					}
					else if(item.getItemName().equals("small shield")){
						Inventory.removeCarryAmount(item.returnWeight());
						itr.remove();
					}
					else if(item.getItemName().equals("rags")){
						Inventory.removeCarryAmount(item.returnWeight());
						itr.remove();
					}
					else if(item.getItemName().equals("bottle")){
						Inventory.removeCarryAmount(item.returnWeight());
						itr.remove();
					}
				}
			}
			else if(ans.equals("no")){
				System.out.println("The potion combiner turns off with a sad, rejected boop.");
			}
		}
	
	}
}
