package Adventure;
import java.util.ArrayList;

/**
 * This is the Room class. These are locations the player can navigate too. Each location has a name, description, and an item arraylist.
 * @author Christian
 *
 */

public class Room {
	private String m_title; //name of room
	private String m_description; //description of room
	private boolean m_roomexist; //this boolean is for the navigation method. if it is true that room exists, then the user can navigate to that room
	private ArrayList<Item> items = new ArrayList<>(); //every room has its own instance arraylist of items, starts out empty, to be added to later by location class
	private boolean visited; //keeping track if player has visited room before. way to keep score.
	
	/**
	 * Constructor for Room.
	 * @param title (the name of the room)
	 * @param description (the description of the room)
	 * @param roomexist (see Location's setRooms and removeRooms methods)
	 */
	public Room(String title, String description, boolean roomexist){
		m_title = title;
		m_description = description;
		m_roomexist = roomexist;
		visited = false;
	}
	//------------------------ITEMS--------------------------------------------------------
	/**
	 * Allowing the player to take items from a room and add it to their inventory.
	 * Goes through room's item array and adds item to inventory if item exists in the room's item array, removes item from room.
	 * If item is coins, then adds amount of coins to inventory coin count, then removes coins item from room.
	 * @param string (item name)
	 * @param inventory (items the player is holding)
	 * @author Kai
	 */
	public void takeItem(String string, ArrayList<Item> inventory){
		boolean founditem = false; //boolean to see if searching through room arraylist 
		if(items.size() == 0){ //if room array has no items
			System.out.println("There is nothing here to take.");
			founditem = true;
		}
		if(!founditem){
			for (int i = 0; i < items.size(); i++){ //goes through room's item array
				if (items.get(i).getItemName().equals(string)){ //if item array has item that has name equal to input string
					founditem = true; //found the item in room arraylist.
					if(string.equals("coins")){//for coins
						int numofcoins = (items.get(i)).getQuantity(); //calling method getnumofCoins to return number of coins the Coin object has.
						Inventory.addCoins(numofcoins); //calls static method addCoins from Inventory class to add number of coins to player inventory
						items.remove(items.get(i)); //removing coin item from room array
					}
					else{ //for rest of items
						if(items.get(i).isTakeable()){
							/**
							 * Checking to see if player can hold item's weight
							 */
							if(Inventory.getCarryAmount()+items.get(i).returnWeight()<=Inventory.getCarryWeight()){
								Inventory.addtoInventory(items.get(i), inventory); //add to player inventory
								System.out.println("You pick up the "+ items.get(i).getItemName());
								Inventory.addCarryAmount(items.get(i).returnWeight());
								items.remove(items.get(i)); //remove from room item array
							}
							else{
								System.out.println("I can't hold that many things!");
							}
						}
						else{
							System.out.println("I can't pick that item up!");
						}
					}
				}
			}
		}
		if(founditem == false){ //if item was not found in room array, aka if founditem was never set to true;
			System.out.println("That item is not in this room");
		}
	}
	/**
	 * Allowing the player to drop an item from their inventory into the room they are in.
	 * Goes through player inventory to find item, adds item to room, removes item from inventory.
	 * If item is coins, then decreases coin count to 0, and adds coins item to room with amount of coins player had previously
	 * @param string (item name)
	 * @param inventory (items the player is holding)
	 * @author Kai
	 */
	public void dropItem(String string, ArrayList<Item> inventory){
		if(string.equals("coins")){ //coins are not an actual item in inventory, so have to program a little differently.
			int numofcoins = Inventory.numofCoins(); //calls numofCoins static method from Inventory class, returns current number of coins player has, stores it in int variable numofcoins.
			if(numofcoins == 0){
				System.out.println("You don't have any coins."); //if player does not have any coins
			}
			else{
				this.addItem(new Coin("coins", "A pile of small, gold coins.", true, "", 0, numofcoins)); //creates new Coin item and puts it into room's item arraylist. the number of coins put depends on how many coins the player is currently holding. drop coins drops all of the player's coins.
				Inventory.removeCoins(); //sets number of coins being held in inventory to zero
			}
		}
		else if(inventory.size() == 0){ //if the player does not have any items
			System.out.println("You aren't holding anything right now.");
		}
		boolean foundItem = false;
		for (int i = 0; i < inventory.size(); i++){ //goes through player's inventory to see if item exists in inventory. if inventory empty, this for-loop will not execute.
			if (inventory.get(i).getItemName().equals(string)){
					foundItem = true;
					System.out.println("You drop the "+ string);
					this.addItem(inventory.get(i)); //add to room item array
					Inventory.removeCarryAmount(inventory.get(i).returnWeight());
					Inventory.removefromInventory(inventory.get(i), inventory); //remove from player inventory
				
			}
		}
		if(!foundItem){
			System.out.println("You don't have that item with you right now.");
		}
	}
	/**
	 * Adds item to room's item arraylist
	 * @param item
	 */
	public void addItem(Item item){ //adding item to room item arraylist.
		items.add(item);
	}
	/**
	 * Prints the items in the room's arraylist. If there are no items in the room, nothing is printed. If item is not takeable, does not print item.
	 * @return string (the items the player is holding)
	 */
	public String printRoomItems(){ 
		String string = "";
		for(int i=0; i<items.size(); i++){
			if(items.get(i).isTakeable()){
				if(items.get(i).getItemName().equals("coins")){
					string += "\nYou see "+items.get(i).getItemName() + " here.";
				}
				else{
					string += "\nYou see a "+items.get(i).getItemName() + " here.";
				}
			}
		}
		if(items.size() != 0){
			return string;
		}
		return string;
		
	}
	/**
	 * Accessor for room's item arraylist
	 * @return items (arraylist of player items)
	 */
	public ArrayList<Item> getRoomItems(){
		return items;
	}
	//-----------------------------------------------------------------------------------
	
	/**
	 * Every room has a run method. This allows the room to perform a special action.
	 * @param inventory (items the player is holding)
	 * @author Kai
	 */
	public void run(ArrayList<Item> inventory){
		
	}
	public void run(ArrayList<Item> inventory, ArrayList<Item> items){
		
	}
	/**
	 * Switching the room's existence.
	 */
	public void changeRoomExist(){
		if(m_roomexist == false){ //if the room is set to false, set it to true. else, if true, set it to false.
			m_roomexist = true;
		}
		else{
			m_roomexist = false;
		}
	}
	/**
	 * Changes the room's existence to boolean specified. Overloading changeRoomExist() method.
	 * @param exist (either true if player can go to room, or false if player cannot go to room)
	 * @author Kai
	 */
	public void changeRoomExist(boolean exist){
		m_roomexist = exist;
	}
	/**
	 * Accessor for room's existence
	 * @return boolean (if the room exists or not)
	 * @author Kai
	 */
	public boolean doesRoomExist(){ 
		return m_roomexist;
	}
	/**
	 * Mutator for room's title
	 * @param string (the name of the rooom)
	 * @author Christian
	 */
	public void setTitle(String string){ 
		m_title = string;
	}
	/**
	 * Mutator for room's description
	 * @param string (description of room)
	 * @author Christian
	 */
	public void setDescription(String string){
		m_description = string;
	}
	/**
	 * Accessor for room's title
	 * @return string (title of room)
	 */
	public String getTitle(){
		return m_title;
	}
	/**
	 * Accessor for room's description
	 * @return string (description of room)
	 */
	public String getDescription(){
		return m_description;
	}
	/**
	 * Accessor for if room has been visited before
	 * @return boolean (if player has visited)
	 */
	public boolean hasVisited(){
		return visited;
	}
	/**
	 * Mutator for room's visited before boolean
	 */
	public void visitedRoom(){
		visited = true;
	}
	/**
	 * Prints out the items in the room
	 */
	public String returnItems(){
		return "";
	}
	/**
	 * Returns room's arraylist of items
	 * @return arraylist<item>
	 */
	public ArrayList<Item> getItems(){
		return items;
	}
	/**
	 * Overriding the toString method().
	 * @return string (The room name along with its description and the items in the room)
	 */
	public String toString(){
		return "Location: " + m_title + "\n----\n" + m_description + " " + printRoomItems();
		
	}
	
	
}
