package Adventure;
import java.util.Scanner;
public class Input {
	public static String getInput(){
		String input;
		System.out.print("> ");
		Scanner scan = new Scanner(System.in); //not sure how to close this?
		input = scan.nextLine();
		input = input.toLowerCase();
		return input;
	}
	
}
