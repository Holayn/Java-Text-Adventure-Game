package Adventure;

import java.util.LinkedList;
import jsjf.EmptyCollectionException;
import jsjf.QueueADT;

/**
 * Implementation of a queue using a linked list
 * @author Kai Wong, Christian Deleaon
 * @param <T> Generic element data type
 * 
 */
public class LinkedQueue<T> implements QueueADT<T>{
	private int count; //keeping track of how many elements in queue
	LinkedList<T> list; //linked list. using this to implement queue
	/**
	 * Constructor for LinkedQueue. Instantiates a new LinkedList of generic type.
	 */
	public LinkedQueue(){
		list = new LinkedList<T>(); //creates a new empty linked list
		count = 0; //initial size of LinkedQueue is 0.
	}
	/**
	 * Enqueues an element to the queue by adding an element to the linked list
	 */
	public void enqueue(T elem){
		if(this.isEmpty()){
			list.add(elem);
		}
		else{
			list.add(elem);
		}
		count++; //increases size of queue by one
	}
	/**
	 * Dequeues an element from the queue by removing the first element in the linked list
	 */
	public T dequeue() throws EmptyCollectionException{
		if(this.isEmpty()){
			throw new EmptyCollectionException("queue");
		}
		count--; //decreases size of queue by one because removing an element from front
		return list.removeFirst(); //removes first element of queue
	}
	/**
	 * Returns the first element from the queue by returning the first element in the linked list
	 */
	public T first() throws EmptyCollectionException{
		if(this.isEmpty()){
			throw new EmptyCollectionException("queue");
		}
		else{
			return list.getFirst();
		}
	}
	/**
	 * Returns true if queue is empty. Otherwise, returns false
	 */
	public boolean isEmpty(){
		if(count == 0){
			return true;
		}
		else{
			return false;
		}
	}
	/**
	 * Returns the size of the queue by returning count variable
	 */
	public int size(){
		return count;
	}
	/**
	 * Returns the string representation of the queue by returning the string representation of the linked list
	 */
	public String toString(){
		return list.toString();
	}
}
