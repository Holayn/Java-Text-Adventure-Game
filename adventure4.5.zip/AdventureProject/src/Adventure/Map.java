package Adventure;
/**
 * Map class
 * @author Christian
 *
 */
public class Map extends Item {
	//private int currentLocation;
	//private String aa = "", ab = "", ac = "", ad = "", ba = "", bb= "", bc = "", bd = "", ca = "", cb = "dfdf", cc = "", cd = "";
	private String map = 
			  "|--------------|--------------|--------------|				\n"
			+ "|   Magic Shop      Market       Food Store  |\n"
			+ "|--------------|------  ------|--------------|\n"
			+ "               |    Hallway   |    Library   |\n"
			+ "               |------  ------|------  ------|--------------|\n"
			+ "               |      Lab          Bedroom       Bathroom   |\n"
			+ "               |--------------|--------------|--------------|\n";
	//make this extend item class, override getDescription() method
	
	//construtor, calls parent class Item
	public Map(String name, String description, boolean bool, String cost, int weight){
		super(name, description, bool, cost, weight);
	}
	public void showMap(int roomx, int roomy){ //printing map
		System.out.println(map);
	}
}
