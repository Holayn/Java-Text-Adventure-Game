/**
 * This program is a text-adventure game called "Potion turned to Poison" by Kai Wong, Christian Deleaon, and Kostikey Mustakas.
 * 
 * @author Kai Wong, Christian Deleaon, Kostikey Mustakas
 * @version 4.5
 * @since 2016-4-29 10:10 AM
 * Changelog: 
 * - fixed lots of bugs in Shop. poly stuff. made check and run methods. 
 * - made it so location would only print after moving to new room. otherwise have to use look/l command to see room description and location again.
 * - added names to parts of code people wrote
 * - added even more javadoc comments.
 * - added IOException catch phrase
 * - added binary search for shoplist, linked list is now copied into array
 * - implementing stack and queue for history
 * - added score keeping, move tracking, endgame stats
 * - added cost and weight to items
 * - added vault, its clues, and everything related to it. added vault test driver.
 * - added endgame function and process (potion combiner and items needed for it to activate)
 * - added more room decoration items and descriptions
 */

package Adventure;
import java.util.ArrayList;
import java.io.*;

public class Main {
	public static void main(String[] args) throws IOException{
		final int WIDTH = 4; //x-dimension of the rooms array
		final int HEIGHT = 3; //y-dimension of the rooms array
		boolean stillPlaying = true; //boolean for running game. if false, game ends.
		int moves = 0; //keeping track of total number of moves player makes
		String input;
		/**
		 * Instantiating rooms as a 2D array
		 * @author Kai
		 */
		Room[][] rooms = new Room[WIDTH][HEIGHT];
		/**
		 * Instantiating inventory as an array list
		 * @author Kai
		 */
		ArrayList<Item> inventory = new ArrayList<>();
		/**
		 * Instantiating rooms in the 2D rooms array.
		 * @author Kai
		 */
		Location.makeRooms(rooms, WIDTH, HEIGHT);
		/**
		 * Instantiating items into all of the rooms' item arrays.
		 * @author Kai
		 */
		Location.makeItems(rooms);
		//opening text of program
		System.out.println("Welcome to \"Potion turned to Poison!\" an interactive text-adventure game!\n\nType help if you get stuck!\n");
		System.out.println("You are a scientist who is approaching his late fifties, and your hair is not what it used to be.");
		System.out.println("Desperate for a cure, you concoct a mixture in your lab. After downing the substance, you suddenly feel");
		System.out.println("your bowels grow heavy. You touch your head, but no hair has grown. However, you now have a serious");
		System.out.println("case of diarrhea and you need a cure. Fast.\n");
		/**
		 * Prints the room title, description, and items it contains.
		 * @author Christian
		 */
		Location.printRoom(rooms);
		while(stillPlaying){
			/**
			 * Executes every room's run method.
			 * @author Kai
			 */
			Location.check(rooms, inventory);
			/**
			 * Input section
			 * @author Christian
			 */
			input = Input.getInput();
			/**
			 * Outputs string of all commands available to the player
			 */
			if (input.equals("h") || input.equals("help")){
				System.out.println("Commands:\n n to move north\n s to move south\n e to move east\n w to move west\n q or quit to quit\n m to see map\n h for help\n take/drop item to take/drop an item\n x or examine to examine an item\n l or look to see current location and room description\n i or inventory to see inventory\n open thing to open a thing");
				System.out.println(" Your moves are being tracked! Each time you enter a command, the number of moves you have taken is incremented by one.");
			}
			/**
			 * Ends the program. Prints out the player's final status, by printing final score, final inventory, final amount of gold
			 * and items purchased from the magic shop.
			 * @author Christian
			 */
			else if (input.equals("q") || input.equals("quit")){
				System.out.println("Thanks for playing!");
				System.out.println("-------------------YOUR FINAL STATUS--------------------");
				System.out.println("Your final score: "+Location.getScore());
				System.out.println("Your final inventory: "+inventory);
				System.out.println("Your final amount of gold: "+Inventory.numofCoins());
				System.out.println("Your items purchased: "+rooms[0][0].returnItems()); //rooms[0][0] is the magic shop.
				System.out.println("--------------------------------------------------------");
				stillPlaying = false;
				/**
				 * Ask if player wants to review actions forwards or backwards
				 */
				Location.reviewActions();
			}	
			/**
			 * Input displays the map if the player has it in their inventory.
			 * @author Kai
			 */
			else if (input.equals("m") || input.equals("map")){ 
				if(inventory.size() > 0){ //determining if player has map in inventory
					for (int i = 0; i < inventory.size(); i++){
						if (inventory.get(i).getItemName().equals("map")){ //only shows map if player has it in their inventory
							inventory.get(i).showMap(Location.getCurrentRoomx(), Location.getCurrentRoomy());
						}
						else{
							System.out.println("You need to be holding the map first to look at it.");
						}
					}
				}
				else{ //if inventory is empty
					System.out.println("You need to be holdng the map first to look at it.");
				}
			}
			/**
			 * Outputs the room's location and description
			 * @author Christian
			 */
			else if (input.equals("l") || input.equals("look")){
				Location.printRoom(rooms);
			}
			/**
			 * Allowing the player to navigate between rooms. Calls Location class's Navigation method
			 * @author Kai
			 */
			else if (input.equals("n") || input.equals("north")){
				Location.Navigation("n", rooms, WIDTH, HEIGHT);
			}
			else if (input.equals("s") || input.equals("south")){
				Location.Navigation("s", rooms, WIDTH, HEIGHT);
			}
			else if (input.equals("e") || input.equals("east")){
				Location.Navigation("e", rooms, WIDTH, HEIGHT);
			}
			else if (input.equals("w") || input.equals("west")){
				Location.Navigation("w", rooms, WIDTH, HEIGHT);
			}
			/**
			 * Outputs player's inventory contents. Also displays player's current score and skill ratio.
			 * Since moves is executed at end of loop, we add one to moves variable
			 * @author Kai
			 */
			else if (input.equals("i") || input.equals("inventory")){
				System.out.println("Score: "+Location.getScore());
				System.out.println("Number of moves: "+(moves+1)); //moves is executed at end of loop, so need to add one
				if(moves!=0){ //preventing program from dividing by 0
					System.out.println("Skill ratio: "+ (((float)Location.getScore())/(moves+1)));
				}
				else{
					System.out.println("Skill ratio: "+ moves);
				}
				System.out.println("Inventory weight: "+Inventory.getCarryAmount()+"/30");
				Inventory.getInventory(inventory);
			}
			/**
			 * Allows player to pick up and place items into their inventory, or drop items from their inventory into the room they are in.
			 * @author Kai
			 */
			else if (input.length() > 4 && input.substring(0, 4).equals("get ")){
				String str;
				//reads after 4th character
				str = input.substring(4);
				//calls static method takeItem in Location class
				Location.takeItem(str, inventory, rooms);
			}
			else if (input.length() > 5  && input.substring(0, 5).equals("take ")){
				String str;
				//reads after 5th character
				str = input.substring(5);
				//calls static method takeItem in Location class
				Location.takeItem(str, inventory, rooms);
			}
			else if (input.length() > 2 && input.substring(0, 2).equals("t ")){
				String str;
				//reads after 2nd character
				str = input.substring(2);
				Location.takeItem(str, inventory, rooms);
			}
			else if (input.length() > 5 && input.substring(0, 5).equals("drop ")){
				String str;
				str = input.substring(5);
				Location.dropItem(str, inventory, rooms); //calls static method dropItem in Location class.
			}
			/**
			 * Allows the player to examine items in their environment as well as in their inventory
			 * @author Kai
			 */
			else if (input.length() > 8 && input.substring(0, 8).equals("examine ")){
				String str;
				str = input.substring(8);
				//calls static method examineItem in Location class
				Location.examineItem(str, inventory, rooms);
			}
			//shorthand notation for examine
			else if (input.length() > 2 && input.substring(0, 2).equals("x ")){
				String str;
				str = input.substring(2);
				Location.examineItem(str,  inventory,  rooms);
			}
			else if (input.length() > 5 && input.substring(0, 5).equals("open ")){
				String str;
				str = input.substring(5);
				Location.openThing(str, inventory, rooms);
			}
			else{
				System.out.println("That is not a valid command.");
			}
			/**
			 * Sets all rooms to false existence after every iteration. Prevents bug where player can move between
			 * adjacent rooms in an array, even if there is no "doorway" between them. This way, we only set rooms to true existence
			 * if the player is allowed to move to them from the room they are currently in.
			 * @author Kai
			 */
			Location.removeRooms(rooms, WIDTH, HEIGHT);
			/**
			 * Increments player's number of moves by one.
			 */
			moves++;
		}
	}
}
