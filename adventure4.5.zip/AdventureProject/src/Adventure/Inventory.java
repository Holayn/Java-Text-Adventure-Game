package Adventure;
import java.util.ArrayList;

/**
 * This is the inventory, or the items the player is currently holding. This is implemented with an arraylist.
 * Coins collected are kept track through an int variable.
 * @author Kai
 *
 */

public class Inventory {
	/**
	 * Total amount of weight the player can carry
	 */
	private static int carryweight = 30;
	/**
	 * Current amount of weight player is carrying
	 */
	private static int carryamount = 0;
	/**
	 * Separate variable for the number of coins the player has. Coins are not added as objects to the player's inventory.
	 * When the player picks up a number of coins, that number is added to the current number of coins the player has.
	 */
	private static int numofcoins;
	/**
	 * Adds the item from the room item arraylist to the player's inventory arraylist
	 * @param item (item from room)
	 * @param inventory (player's item inventory)
	 */
	public static void addtoInventory(Item item, ArrayList<Item> inventory){
		inventory.add(item);
	}
	/**
	 * Removes the item from the player's inventory and adds it to the room's item arraylist
	 * @param item (item in inventory)
	 * @param inventory (player's item inventory)
	 */
	public static void removefromInventory(Item item, ArrayList<Item> inventory){
		inventory.remove(item);
	}
	/**
	 * Method to pick up coins from room
	 * @param num (amount of coins being picked up)
	 */
	public static void addCoins(int num){
		System.out.println("You pick up "+num+" coins.");
		numofcoins += num;
	}
	/**
	 * Method to drop coins from player's inventory. Drops all the coins player is holding.
	 */
	public static void removeCoins(){
		System.out.println("You drop all of your coins. You idiot.");
		numofcoins = 0;
	}
	/**
	 * Method allows player to drop a certain number of coins from his/her inventory.
	 * @param num (number of coins player wants to drop)
	 */
	public static void removeCoins(int num){
		numofcoins = numofcoins - num;
	}
	/**
	 * Accessor for numofcoins variable
	 * @return int (number of coins the player is holding)
	 */
	public static int numofCoins(){
		return numofcoins;
	}
	/**
	 * Returns number of coins player has and number of items they have in their inventory.
	 * If player is holding something, display what they have. otherwise, say they don't have anything.
	 * @param inven (inventory of player)
	 */
	public static void getInventory(ArrayList<Item> inven){ 
		if(inven.size() != 0){ 
			System.out.println("You currently have: "+ inven);
		}
		else{
			System.out.println("You currently aren't holding anything.");
		}
		if(numofcoins != 0){ //if player does not have any coins, don't display coin amount
			System.out.println("You have "+numofcoins+" coins in your pocket.");
		}
	}
	/**
	 * Returns amount of weight player is holding
	 * @return int
	 */
	public static int getCarryAmount(){
		return carryamount;
	}
	/**
	 * Returns amount of weight player can hold
	 * @return
	 */
	public static int getCarryWeight(){
		return carryweight;
	}
	/**
	 * Adds to amount of weight player is holding.
	 * @param i
	 */
	public static void addCarryAmount(int i){
		carryamount += i;
	}
	/**
	 * Removes amount of weight player is holding
	 * @param i
	 */
	public static void removeCarryAmount(int i){
		carryamount -= i;
	}
	/**
	 * Overriding toString method
	 * @param inven (player inventory)
	 * @return string (items the player is currently holding)
	 */
	public String toString(ArrayList<Item> inven){
		return "You currently have: "+inven;
	}
	
}
