package Adventure;

public class Search {
	/**
	 * Binary search method. Determines midpoint in array, then compares it to the target. Adjusts midpoint accordingly until
	 * target is found.
	 * @param data (the array being passed in. data being passed in should inherit from Comparable class
	 * @param target (the thing being searched for in the array)
	 * @return Comparable (returns the item found)
	 */
	public static <T extends Comparable<T>> T binarySearch(T[] data, T target){
		T result = null;
		int first = 0, last = data.length-1, mid;
		while(result == null && first<=last){
			mid = ((first+last)/2);
//			System.out.println(data[mid]);
//			System.out.println(mid);
//			System.out.println(first);
//			System.out.println(last);
			if(data[mid].compareTo(target) == 0){
				result = data[mid];
			}
			else if(data[mid].compareTo(target) < 0){
				first = mid + 1; //have to add one, or will get fraction
			}
			else if(data[mid].compareTo(target) > 0){
				last = mid - 1; //have to subtract one or will get fraction
			}
		}
		return result;
	}
}
