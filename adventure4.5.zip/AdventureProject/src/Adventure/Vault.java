package Adventure;
/**
 * This class is the vault that the player may open after giving the correct password. Puts treasure into library.
 * @author Kai Wong
 *
 */
public class Vault implements Lockable{
	private String password;
	private String clue;
	private boolean locked = true;
	/**
	 * Constructor for vault
	 * @param password (password to open vault)
	 * @param clue (clue for password to vault)
	 */
	public Vault(String password, String clue){
		this.password = password;
		this.clue = clue;
	}
	/**
	 * Locks the vault
	 */
	public void lockVault(){
		locked = true;
	}
	/**
	 * Unlocks the vault
	 */
	public void unlockVault(){
		locked = false;
	}
	/**
	 * Mutator for password
	 * @param str
	 */
	public void setKey(String str){
		password = str;
	}
	/**
	 * Accessor to see if vault is unlocked or not
	 * @return boolean (returns true if vault is locked)
	 */
	public boolean vaultLocked(){
		return locked;
	}
	/**
	 * Accessor for vault password
	 * @return string (password)
	 */
	public String getPassword(){
		return password;
	}
	/**
	 * Accessor for vault clue
	 * @return string (clue for password)
	 */
	public String getClue(){
		return clue;
	}
	/**
	 * Sets password to poop.
	 */
	public void setKey(){
		password = "poop";
	}
	/**
	 * Prints the vault's locked status.
	 */
	public void vaultStatus(){
		System.out.println("Vault locked: "+locked);
	}
}
